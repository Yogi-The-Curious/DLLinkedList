public class Person {
    private String firstName;
    private String lastName;
    private String iD;

    public Person(String firstName,String lastName,String iD) throws InvalidLengthException {
        // will have to implement a custom catch later, getting too tired
        this.firstName = firstName;
        this.lastName = lastName;
        checker(iD);
        this.iD = iD;
    }

    private void checker (String iD) throws InvalidLengthException {

        if(iD.length() != 9){
            throw new InvalidLengthException("iD must be 9 characters long  :" + this.firstName);
        }
    }
    public String getFirstName() {
        return firstName;
    }

    public String getiD() {
        return iD;
    }

    public String getLastName() {
        return lastName;
    }

    @Override
    public String toString() {
        return "Person{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", iD='" + iD + '\'' +
                '}';
    }
}
