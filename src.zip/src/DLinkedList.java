public class DLinkedList<T> implements DLinkedListI<T> {

    private int size;
    private Node<T> first;
    private Node<T> last;

    public DLinkedList(){
        size = 0;
        first = null;
        last = null;
    }
    // need to implement some sort of conversion from any data into a node to be utilized.

    @Override
    public void add(int index, T e){


        // turning the object into a Node, hopefully this runs smoothly with the object to parametrized type cast.
        Node<T> newNode = toNode(e);

        // if an item already exists at the chosen index we insert param e into that index
        if (index < size()) {
            Node<T> curNode = getNode(index); //retrieves node in index spot
            newNode.setNext(curNode);  // sets that node to the next position of our new node
            newNode.setPrev(curNode.getPrev());
            curNode.getPrev().setNext(newNode);
            curNode.setPrev(newNode);
            size += 1;
        }

        // if no item exists at the chosen index but there is a previous we simply call addLast

        else if (index == size()) {
            addLast(e);
        }

        // if index is 0 we add first or if size is 0 we add first

        else if (index == 0 || size() == 0) {
            addFirst(e);
        } else {
            System.out.println("index is out of bounds, object will be added to the end of list");
            addLast(e);
            last = newNode;
        }

    }

    @Override
    public void addFirst(T e){

            Node<T> newNode = toNode(e);
            // this little bit to catch the first entry into a list
            if (size() == 0) {
                last = newNode;
                newNode.setNext(newNode);
                newNode.setPrev(newNode);
            } else {
                Node<T> curFNode = first;
                Node<T> curLNode = last;

                newNode.setPrev(curLNode);
                newNode.setNext(curFNode);

                curFNode.setPrev(newNode);
                curLNode.setNext(newNode);

            }
            first = newNode;
            size += 1;
        }

    @Override
    // this is oddly symmetrical to addFirst, with a minor change, we will see what becomes of this.
    public void addLast(T e){

            Node<T> newNode = toNode(e);
            // this little bit to catch the first entry into a list
            if (size() == 0) {
                first = newNode;
                newNode.setNext(newNode);
                newNode.setPrev(newNode);
            }
            else {
                Node<T> curFNode = first;
                Node<T> curLNode = last;

                newNode.setPrev(curLNode);
                newNode.setNext(curFNode);

                curFNode.setPrev(newNode);
                curLNode.setNext(newNode);

            }
            last = newNode;
            size += 1;

    }


    @Override
    // here we must walk through the entire list, so we can see the O(n) showing up.
    public T get(int index) {
        if (getNode(index) != null) {

            return getNode(index).getData();
        }
        else {
            System.out.println("you have entered an out of bounds index and we have not yet written a catch for this");
            return null;
        }
    }


    // returns the specified node (provides the working part of get(index) and allows for internal calls to retrieve nodes)
    private Node<T> getNode(int index) {
        if (index < size()) {

            // initializing a method variable to begin our search a the start of the list.
            Node<T> curNode = first;

            for (int i = 0; i < (index); i++) {
                curNode = curNode.getNext();
            }
            return curNode;
        }
        else {
            System.out.println("you have entered an out of bounds index and we have not yet written a catch for this");
            return null;
        }
    }


    // may have to do some sort of try catch or something for a null pointer exception!
    @Override
    public T getLast(){
        if(size()==0){
            System.out.println("nothing in list to return");
            return null;
        }
        return last.getData();
    }

    @Override
    public T getFirst(){
        if(size()==0){
            System.out.println("nothing in list to return");
            return null;
        }
        return first.getData();
    }


    public int size(){
        return size;
    }


    @Override
    public void deleteFirst(){
        if (size() >= 1){
        Node<T> firstNode = first;
        Node<T> lastNode =last;
        Node<T> nextNode = firstNode.getNext();

        //setting the references for each node
        nextNode.setPrev(lastNode);
        lastNode.setNext(nextNode);

        //setting nextNode as firstNode
        first =nextNode;

        size -=1;
        }

        else {
            System.out.println("nothing in list to delete");
        }

    }

    @Override
    public void deleteLast(){

        if(size() >= 1) {

            Node<T> firstNode = first;
            Node<T> lastNode = last;
            Node<T> nextNode = lastNode.getPrev();

            //setting the references for each node
            nextNode.setNext(firstNode);
            firstNode.setPrev(nextNode);

            //setting nextNode as firstNode
            last = nextNode;
            size -= 1;
        }
        else{
            System.out.println("nothing to delete");
        }
    }

    @Override
    public void delete(int index){
        if(index < size()) {
            Node<T> currentNode = getNode(index);
            Node<T> prevNode = currentNode.getPrev();
            Node<T> nextNode = currentNode.getNext();

            prevNode.setNext(nextNode);
            nextNode.setPrev(prevNode);

            size -= 1;
        }
        else{
            System.out.println("that index does not exist");
        }
    }

    @Override
    // this really depends on if java will throw the linked list away once it recognizes that data has no connection to running methods.
    // the method gains complexity if each link of the list must be broken individually.
    public void clear() {
        first = null;
        last = null;
        size = 0;
    }


    @Override
    public boolean contains(Object e){
        boolean isFound = false;

        for(int i = 0; i<size(); i++){
            Node<T> current = getNode(i);
            if(e.equals(current.getData())){
                isFound = true;
            }
        }

        return isFound;
    }

    @Override
    public void set(int index, Object e) {
        if ((index < size) && (e != null)) {
            T data = (T)e;
            Node<T> oldNode = getNode(index);
            oldNode.setData(data);
        }
    }

    /*
    A custom method I have added to give this class better functionality.
    Takes any data type and returns a node with the input as the data field.
     */
    private Node<T> toNode(T e){
           //T newType = (T)e; // this is a weak point here. Be wary
            return new Node<>(e);
        }


}
