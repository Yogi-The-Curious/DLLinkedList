import java.io.IOException;

public class Main {
    public static InputOutput inOut;
    public static void main(String[] args) throws IOException {
        // create a reader object (must write tests for that object)
        // call that objects add method
        inOut = new InputOutput();
        inOut.enterInput();
        inOut.report();
        inOut.x2();
        inOut.report();
        inOut.writeOutput();
    }
}
