public class Node <T> {

    private T data;
    private Node<T> next;
    private Node<T> prev;

    public Node(T data){
        this.data = data;
        next = null;
        prev = null;
    }

    public void setNext(Node<T> node){
        next = node;
    }

    public void setPrev(Node<T> node){
        prev = node;
    }

    public T getData(){
        return data;
    }

    public Node<T> getNext(){
        return next;
    }

    public  Node<T> getPrev(){
        return prev;
    }

    public void setData(T e){
        data = e;
    }
}
