import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.*;

class DLinkedListTest {

    private static List<Person> people;
    private DLinkedList<Person> myList;
    private DLinkedList<Person> filledList;
    @org.junit.jupiter.api.BeforeEach
    void setUp() throws InvalidLengthException {
        // creating a small data set to use
        people = new ArrayList<Person>();
        people.addAll(Arrays.asList(new Person("Randers","McG","A29764028"),
                new Person("Clara","Gert","C29046821"), new Person("Jen","Flanders","RT2067G69"),
                new Person("Ted","Sempi","8OP90136T")));


        myList = new DLinkedList<>();


        filledList = new DLinkedList<>();
        for (Person person : people) {
            filledList.addLast(person);
        }


    }

    @org.junit.jupiter.api.AfterEach
    void tearDown() {
    }

    @org.junit.jupiter.api.Test
    void add() {

        //System.out.println(people.size());
        myList.add(0,people.get(0));
        System.out.println("\033[1mshould see 'index out of bonds adding last' next line\033[0m");
       myList.add(3,people.get(1)); // tests index out of bound add (should add last and then move on)
       myList.add(1,people.get(2));
        assertEquals(3,myList.size());
        assertEquals("Jen",myList.get(1).getFirstName()); // checks the add to a spot already filled
    }

    @org.junit.jupiter.api.Test
    void addFirst() {
        myList.addFirst(people.get(3));
       assertEquals(1,myList.size());
       assertEquals("Ted",myList.getFirst().getFirstName());
       myList.addFirst(people.get(2));
       assertEquals("Flanders",myList.getFirst().getLastName());
    }

    @org.junit.jupiter.api.Test
    void addLast() {
        myList.addLast(people.get(0));
        assertEquals("Randers",myList.getFirst().getFirstName());
        myList.addLast(people.get(3));
        assertEquals("Ted",myList.getLast().getFirstName());
    }

    @org.junit.jupiter.api.Test
    void get() {
        System.out.println("\033[1mShould see index out of bounds in following line\033[0m");
        myList.get(0); // should get an index out of bounds printing
        assertEquals("Clara",filledList.get(1).getFirstName());
        assertEquals("Randers",filledList.get(0).getFirstName());
        assertEquals("8OP90136T",filledList.get(3).getiD());
    }

    @org.junit.jupiter.api.Test
    void getLast() {
        System.out.println("\033[1mshould see 'nothing in list' next line\033[0m");
        myList.getLast();// again we should get an index out of bounds printing
        assertEquals("Sempi",filledList.getLast().getLastName());
    }

    @org.junit.jupiter.api.Test
    void getFirst() {
        System.out.println("\033[1mshould see 'nothing in list' next line\033[0m");
        myList.getFirst(); // another index out of bounds printing should appear
        assertEquals("Randers",filledList.getFirst().getFirstName());
    }

    @org.junit.jupiter.api.Test
    void size() {
        assertEquals(0, myList.size());
        assertEquals(4,filledList.size());
    }

    @org.junit.jupiter.api.Test
    void deleteFirst() {
        System.out.println("\033[1mshould see 'nothing to delete' next line\033[0m");
        myList.deleteFirst(); // this should return a printing
        filledList.deleteFirst();
        assertEquals("Clara",filledList.getFirst().getFirstName());
        assertEquals("Ted",filledList.get(2).getFirstName());
    }

    @org.junit.jupiter.api.Test
    void deleteLast() {
        System.out.println("\033[1mshould see 'nothing to delete' next line\033[0m");
        myList.deleteLast();
        filledList.deleteLast();
        assertEquals("Jen",filledList.getLast().getFirstName());
        assertEquals("RT2067G69",filledList.get(2).getiD());
    }

    @org.junit.jupiter.api.Test
    void delete() {
        System.out.println("\033[1mshould see 'index out of bounds' next line\033[0m");
        myList.delete(4);
        filledList.delete(1);
        assertEquals("Flanders",filledList.get(1).getLastName());
    }

    @org.junit.jupiter.api.Test
    void clear() {
        filledList.clear();
        assertEquals(0,filledList.size());
        myList.clear();
    }

    @org.junit.jupiter.api.Test
    void contains() {
        assertTrue(filledList.contains(people.get(0)));
        filledList.deleteFirst();
        assertEquals(false,filledList.contains("randers"));
        assertEquals(false,filledList.contains(people.get(0)));
    }

    @org.junit.jupiter.api.Test
    void set() throws InvalidLengthException {
        try {
            Person insertion = new Person("Tina", "Crocodile", "K1289L785");

            filledList.set(0, insertion);
            assertEquals("Tina", filledList.getFirst().getFirstName());
            assertEquals("Ted", filledList.get(3).getFirstName());
        }
        catch(InvalidLengthException e){
            System.out.println("The iD length was too long for insertion person! ");
        }

    }
}