import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MainTest {
    private InputOutput inOut;
    @BeforeEach
    void setup() {
        inOut = new InputOutput();
    }

    @Test
    // will fail if data set is foreign.
    void inputTest(){

        inOut.enterInput();
        assert(inOut.myList.getFirst() == 56);
        assert(inOut.myList.getLast()==12);
    }
    void multiplyTest() {
        int x = inOut.myList.getFirst();
        int y = inOut.myList.getLast();
        inOut.x2();
        assertTrue(inOut.myList.getFirst() == x*2);
        assertTrue(inOut.myList.getLast() == y*2);
    }

}