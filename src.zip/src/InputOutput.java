import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.io.File;
public class InputOutput {

    public DLinkedList<Integer> myList;
    private String inputFilename;
    private String outputFilename;

    public InputOutput(){
        inputFilename = "C:/Users/benru/IdeaProjects/src/test.txt";
        outputFilename = "C:/Users/benru/IdeaProjects/src//outputTest.txt";
        myList = new DLinkedList<>();
    }

    public InputOutput(String inputFilename,String outputFilename){
        this.myList = new DLinkedList<>();
        this.inputFilename = inputFilename;
        this.outputFilename = outputFilename;


    }
    // read the input from the file using try catches to verify its correct
    // as we read each line, input it into the list
    // must account for exceptions!!!
    public void enterInput(){
         try {
            File input = new File(inputFilename);
            Scanner parser = new Scanner(input);
            while (parser.hasNextInt()) {
                myList.addLast(parser.nextInt());
            }
                    }
        catch(FileNotFoundException e){
            System.out.println("file not found");
        }


    }
    // run through the linked list and multiply each entry by two
    // this would work better if my written list class had a modify method.
    // there are many ways to navigate this, and this is by far not the most efficient however it works for now and thats fine by me.
    public void x2(){
        int size = myList.size();
        DLinkedList<Integer> temp = new DLinkedList<>();
        for(int i = 0; i< size; i++){
            int y =myList.get(i);
            y *= 2;
            temp.addLast(y);
        }
        myList = temp;

    }
    // must remember to account for exceptions
    public void writeOutput()
     {
        try {
            FileWriter writer = new FileWriter(outputFilename);
            int size = myList.size();
            for (int i = 0; i < size; i++) {
                writer.write((myList.get(i).toString())); // doesn't want to write int natively!
                writer.write("\n");
            }
            writer.close();
        }
        catch(FileNotFoundException e){
            System.out.println("file not found");
        }
        catch(IOException e){
            System.out.println("failed to write to file");
        }
    }
    public void report(){
        System.out.println("Now Printing test string");
        for(int i=0; i<myList.size(); i++){
            System.out.println(myList.get(i));
        }
    }
}
