public class InvalidLengthException extends Exception{
    InvalidLengthException(String msg){
        super(msg);
    }
}
