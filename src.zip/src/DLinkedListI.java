interface DLinkedListI <E> {

    /*
    adds a class type  E (so node<T>) to the list at the specified index
     */
    void add(int index, E e);

    /*
    adds an element to the first spot of the list
     */
    void addFirst(E e);

    /*
    adds an element to the last spot of the list
     */
    void addLast(E e);

    /*
    deletes the element at the specified index.
     */
    void delete(int index);

    /*
    deletes the first element
     */

    void deleteFirst();

    /*
    deletes the last element
     */
    void deleteLast();

    /*
    returns the size of the list
     */
    int size();

    /*
    clears the elements of the list
     */

    void clear();

    /*
    checks to see if the list contains the specified element
     */
    boolean contains(E e);

    /*
    retrieves the element
     */

    E get(int index);

    E getFirst();

    E getLast();

    /*
    sets an object at a specified index
     */

    void set(int index, E object);
}
